package utilities;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	
	
	public static WebDriver driver;
	
	public WebDriver getDriver() {
	try {
	
	FileInputStream file = new FileInputStream("src\\test\\java\\utilities\\system.properties");
	Properties prop = new Properties();
	prop.load(file);
	String getBrowser = prop.getProperty("browser");
	String url = prop.getProperty("url");
	
	if (getBrowser.contains("chrome")) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Aritra\\Study\\Selenium Automation\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
	}
	}
				
	catch(Exception e) {
		System.out.println("Unable to launch browser: "+e.getMessage());
	}
	
	
	return driver;

}
	
	}

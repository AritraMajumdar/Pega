package step;




import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.ensure.Ensure;
import reusableLibrary.loginPegaWeb;
import utilities.BaseClass;


public class firstStep extends BaseClass {
	
	WebDriver driver=getDriver();
	loginPegaWeb lp = new loginPegaWeb(driver);

    
	@Given("user navigates to proper site")
	public void user_navigates_to_proper_site() throws IOException {

	Ensure.that(driver.getTitle()).contains("U+Bank Retail");
		
	}
	
	@When("{string} logs into the system")
	public void logs_into_the_system(String userName) {
	    // Write code here that turns the phrase above into concrete actions
		
		lp.login().click();
		Select s1=lp.selectUser();
		int customerList= s1.getOptions().size();
		for (int i=0;i<customerList;i++) {
			if(s1.getOptions().get(i).toString().equalsIgnoreCase(userName)) {
				s1.selectByIndex(i);
			
			}
		}
		 
		lp.signinButton().click();
		}

	
	
	@Then("validate that proper {string} are displayed")
	public void validate_that_proper_are_displayed(String offername) {
			
		Ensure.that(lp.cardCheck().getText()).contains(offername);
	}


}

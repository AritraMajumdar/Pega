package reusableLibrary;

import org.openqa.selenium.WebDriver;

public class offerValidationPage {

	WebDriver driver;

	public offerValidationPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	
}

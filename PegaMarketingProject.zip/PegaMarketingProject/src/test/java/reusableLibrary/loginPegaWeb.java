package reusableLibrary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class loginPegaWeb {
	
	WebDriver driver;
	
	
	public loginPegaWeb(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[@class='launch-login']")
	WebElement loginButton;	
	
    @FindBy(id="username")
    WebElement userList;
    
    @FindBy(xpath="//button[@class='sign-in']")
    WebElement signinButton;
    
    @FindBy(xpath="//div[@class='content']/h3")
    WebElement cardName;
    
	public WebElement login() {
		
		return loginButton;
	}
	
	public Select selectUser() {
		
		Select selectList= new Select(userList);
		return selectList;
	}
	
	public WebElement signinButton() {
		
		return signinButton;
	}
	
	public WebElement cardCheck() {
		
		return cardName;
	}
	
	
	

}
